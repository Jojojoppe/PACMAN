/*
 * PowerPellet.cpp
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#include "PowerPellet.h"

namespace PowerPellet {

PowerPellet::PowerPellet() {
	// TODO Auto-generated constructor stub

}

PowerPellet::~PowerPellet() {
	// TODO Auto-generated destructor stub
}

} /* namespace PowerPellet */
