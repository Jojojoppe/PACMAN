/*
 * Wall.cpp
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#include "Wall.h"

namespace Wall {

Wall::Wall() {
	// TODO Auto-generated constructor stub

}

Wall::~Wall() {
	// TODO Auto-generated destructor stub
}

} /* namespace Wall */
