/*
 * Sprite.cpp
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#include "Sprite.h"

namespace Sprite {

Sprite::Sprite() {
	// TODO Auto-generated constructor stub

}

Sprite::~Sprite() {
	// TODO Auto-generated destructor stub
}

} /* namespace Sprite */
