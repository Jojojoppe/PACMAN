/*
 * Dot.cpp
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#include "Dot.h"

namespace Dot {

Dot::Dot() {
	// TODO Auto-generated constructor stub

}

Dot::~Dot() {
	// TODO Auto-generated destructor stub
}

} /* namespace Dot */
