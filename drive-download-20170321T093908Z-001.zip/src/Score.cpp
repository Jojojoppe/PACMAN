/*
 * Score.cpp
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#include "Score.h"

namespace Score {

Score::Score() {
	// TODO Auto-generated constructor stub

}

Score::~Score() {
	// TODO Auto-generated destructor stub
}

} /* namespace Score */
