/*
 * Pos.cpp
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#include "Pos.h"

namespace Pos {

Pos::Pos() {
	// TODO Auto-generated constructor stub

}

Pos::~Pos() {
	// TODO Auto-generated destructor stub
}

} /* namespace Pos */
