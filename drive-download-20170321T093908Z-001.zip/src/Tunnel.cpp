/*
 * Tunnel.cpp
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#include "Tunnel.h"

namespace Tunnel {

Tunnel::Tunnel() {
	// TODO Auto-generated constructor stub

}

Tunnel::~Tunnel() {
	// TODO Auto-generated destructor stub
}

} /* namespace Tunnel */
