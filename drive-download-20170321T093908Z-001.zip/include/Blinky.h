#pragma once

class Blinky : public Ghost{
	
};
