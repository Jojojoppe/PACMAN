/*
 * Wall.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_WALL_H_
#define SRC_WALL_H_

namespace Wall {

class Wall {
public:
	Wall();
	virtual ~Wall();
};

} /* namespace Wall */

#endif /* SRC_WALL_H_ */
