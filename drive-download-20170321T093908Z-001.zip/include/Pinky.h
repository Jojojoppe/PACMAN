#pragma once

class Pinky : public Ghost{
	
};
