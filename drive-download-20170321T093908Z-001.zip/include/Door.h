/*
 * Door.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_DOOR_H_
#define SRC_DOOR_H_

namespace Door {

class Door {
public:
	Door();
	virtual ~Door();
};

} /* namespace Door */

#endif /* SRC_DOOR_H_ */
