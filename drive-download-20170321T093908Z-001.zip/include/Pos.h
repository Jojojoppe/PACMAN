/*
 * Pos.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_POS_H_
#define SRC_POS_H_

namespace Pos {

class Pos {
public:
	Pos();
	virtual ~Pos();
};

} /* namespace Pos */

#endif /* SRC_POS_H_ */
