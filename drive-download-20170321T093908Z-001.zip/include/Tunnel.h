/*
 * Tunnel.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_TUNNEL_H_
#define SRC_TUNNEL_H_

namespace Tunnel {

class Tunnel {
public:
	Tunnel();
	virtual ~Tunnel();
};

} /* namespace Tunnel */

#endif /* SRC_TUNNEL_H_ */
