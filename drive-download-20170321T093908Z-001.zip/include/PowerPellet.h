/*
 * PowerPellet.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_POWERPELLET_H_
#define SRC_POWERPELLET_H_

namespace PowerPellet {

class PowerPellet {
public:
	PowerPellet();
	virtual ~PowerPellet();
};

} /* namespace PowerPellet */

#endif /* SRC_POWERPELLET_H_ */
