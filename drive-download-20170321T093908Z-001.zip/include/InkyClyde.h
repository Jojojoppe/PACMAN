#pragma once

class InkyClyde : public Ghost{
	
};
