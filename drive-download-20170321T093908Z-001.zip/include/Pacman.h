#pragma once

class Pacman : public DynamicObject{
	
};
