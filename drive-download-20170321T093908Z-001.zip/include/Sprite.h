/*
 * Sprite.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_SPRITE_H_
#define SRC_SPRITE_H_

namespace Sprite {

class Sprite {
public:
	Sprite();
	virtual ~Sprite();
};

} /* namespace Sprite */

#endif /* SRC_SPRITE_H_ */
