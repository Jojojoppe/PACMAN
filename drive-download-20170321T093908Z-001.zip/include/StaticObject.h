/*
 * StaticObject.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_STATICOBJECT_H_
#define SRC_STATICOBJECT_H_

namespace StaticObject {

class StaticObject {
public:
	StaticObject();
	virtual ~StaticObject();
};

} /* namespace StaticObject */

#endif /* SRC_STATICOBJECT_H_ */
