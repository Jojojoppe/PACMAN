#pragma once

enum GhostType{
	normal,
	frightened,
	dead
};

class Ghost : public DynamicObject{
	
};
