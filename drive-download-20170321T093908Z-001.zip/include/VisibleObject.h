/*
 * VisibleObject.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_VISIBLEOBJECT_H_
#define SRC_VISIBLEOBJECT_H_

namespace VisibleObject {

class VisibleObject {
public:
	VisibleObject();
	virtual ~VisibleObject();
};

} /* namespace VisibleObject */

#endif /* SRC_VISIBLEOBJECT_H_ */
