/*
 * Fruit.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_FRUIT_H_
#define SRC_FRUIT_H_

namespace Fruit {

class Fruit {
public:
	Fruit();
	virtual ~Fruit();
};

} /* namespace Fruit */

#endif /* SRC_FRUIT_H_ */
