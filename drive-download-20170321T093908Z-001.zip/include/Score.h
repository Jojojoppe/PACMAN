/*
 * Score.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_SCORE_H_
#define SRC_SCORE_H_

namespace Score {

class Score {
public:
	Score();
	virtual ~Score();
};

} /* namespace Score */

#endif /* SRC_SCORE_H_ */
