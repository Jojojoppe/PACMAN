/*
 * Dot.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_DOT_H_
#define SRC_DOT_H_

namespace Dot {

class Dot : StaticObject {
public:

};

#endif /* SRC_DOT_H_ */
