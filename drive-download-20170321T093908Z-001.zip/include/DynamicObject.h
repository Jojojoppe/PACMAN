#pragma once

enum Direction{
	up,
	down,
	left,
	right
};

class DynamicObject : VisibleObject{
	
};
