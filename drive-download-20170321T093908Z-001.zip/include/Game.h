/*
 * Game.h
 *
 *  Created on: 21 mrt. 2017
 *      Author: Joppe Blondel & Hessel den Hertog
 Group[20]
 */

#ifndef SRC_GAME_H_
#define SRC_GAME_H_

class Game
{
public:

};

#endif /* SRC_GAME_H_ */
